package ab5.impl.NACHNAMEN;

import at.syssec.fa.RSA;
import at.syssec.fa.RSAMinimizer;

public class RSAMinimizerImpl implements RSAMinimizer {

	@Override
	public RSA minimize(RSA arg0) {
		// TODO Auto-generated method stub
		return null;
	}
}
